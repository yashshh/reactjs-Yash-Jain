package com.cts.service;

import java.util.List;

import com.cts.model.CompanyDetails;

public interface CompanyService {

	public List<CompanyDetails> getCompanies();
}
